.. _gadget-notebook:

Using yt to view and analyze Gadget outputs
++++++++++++++++++++++++++++++++++++++++++++++++++++++++

.. notebook:: yt_gadget_analysis.ipynb

