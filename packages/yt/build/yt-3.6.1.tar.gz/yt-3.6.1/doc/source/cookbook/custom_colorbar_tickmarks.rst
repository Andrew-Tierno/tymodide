Custom Colorbar Tickmarks
-------------------------

.. notebook:: custom_colorbar_tickmarks.ipynb
