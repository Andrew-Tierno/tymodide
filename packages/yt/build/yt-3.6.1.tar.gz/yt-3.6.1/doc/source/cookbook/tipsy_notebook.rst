.. _tipsy-notebook:

Using yt to view and analyze Tipsy outputs from Gasoline
++++++++++++++++++++++++++++++++++++++++++++++++++++++++

.. notebook:: tipsy_and_yt.ipynb

