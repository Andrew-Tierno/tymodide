Derived Fields and Profiles
---------------------------

.. notebook:: 5)_Derived_Fields_and_Profiles.ipynb
