Simple Visualization
--------------------

.. notebook:: 3)_Simple_Visualization.ipynb
