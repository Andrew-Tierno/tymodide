.. _generic-particle-data:

Loading Generic Particle Data
-----------------------------

.. notebook:: Loading_Generic_Particle_Data.ipynb
