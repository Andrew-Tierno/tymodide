.. _loading-numpy-array:

Loading Generic Array Data
==========================

.. notebook:: Loading_Generic_Array_Data.ipynb
