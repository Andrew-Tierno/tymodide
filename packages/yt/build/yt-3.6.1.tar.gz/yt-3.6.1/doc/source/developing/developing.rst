.. include:: ../../../CONTRIBUTING.rst
