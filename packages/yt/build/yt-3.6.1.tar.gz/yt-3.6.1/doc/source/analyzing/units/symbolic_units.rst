.. _symbolic_units:

Symbolic units: :code:`yt.units`
================================

.. notebook:: 1)_Symbolic_Units.ipynb
   :skip_exceptions:
