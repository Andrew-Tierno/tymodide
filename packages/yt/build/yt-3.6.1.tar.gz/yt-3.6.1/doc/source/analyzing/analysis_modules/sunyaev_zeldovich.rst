.. _sunyaev-zeldovich:

Mock Observations of the Sunyaev-Zeldovich Effect
-------------------------------------------------

.. notebook:: SZ_projections.ipynb
