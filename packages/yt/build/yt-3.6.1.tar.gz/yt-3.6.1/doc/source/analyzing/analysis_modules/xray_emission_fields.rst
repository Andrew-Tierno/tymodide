.. _xray_emission_fields:

X-ray Emission Fields
=====================

.. notebook:: XrayEmissionFields.ipynb
