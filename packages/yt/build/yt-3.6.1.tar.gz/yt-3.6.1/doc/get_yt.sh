echo "This script has been deprecated."
echo "You can now create a conda-based build using install_script.sh"
echo "Please download that script and run it"
exit 0
