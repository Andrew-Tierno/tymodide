"""
This packages contains python packages that are bundled with yt
and are developed by 3rd party upstream.
"""
