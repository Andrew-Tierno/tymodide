# This file is often empty.  It can hold definitions related to a frontend.
